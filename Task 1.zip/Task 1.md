```python
import numpy as np
import pandas as pd 
import seaborn as sns 
import matplotlib.pyplot as plt
import plotly.express as px
import warnings
warnings.filterwarnings('ignore')

```


```python
data = pd.read_csv("C:\\Users\\pramod\\Downloads\\NFL Play by Play 2009-2016 (v3).csv")
data
```

    C:\Users\pramod\AppData\Local\Temp\ipykernel_6276\455096832.py:1: DtypeWarning: Columns (25,51) have mixed types. Specify dtype option on import or set low_memory=False.
      data = pd.read_csv("C:\\Users\\pramod\\Downloads\\NFL Play by Play 2009-2016 (v3).csv")
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>GameID</th>
      <th>Drive</th>
      <th>qtr</th>
      <th>down</th>
      <th>time</th>
      <th>TimeUnder</th>
      <th>TimeSecs</th>
      <th>PlayTimeDiff</th>
      <th>SideofField</th>
      <th>...</th>
      <th>yacEPA</th>
      <th>Home_WP_pre</th>
      <th>Away_WP_pre</th>
      <th>Home_WP_post</th>
      <th>Away_WP_post</th>
      <th>Win_Prob</th>
      <th>WPA</th>
      <th>airWPA</th>
      <th>yacWPA</th>
      <th>Season</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>NaN</td>
      <td>15:00</td>
      <td>15</td>
      <td>3600.0</td>
      <td>0.0</td>
      <td>TEN</td>
      <td>...</td>
      <td>NaN</td>
      <td>0.485675</td>
      <td>0.514325</td>
      <td>0.546433</td>
      <td>0.453567</td>
      <td>0.485675</td>
      <td>0.060758</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>1.0</td>
      <td>14:53</td>
      <td>15</td>
      <td>3593.0</td>
      <td>7.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>1.146076</td>
      <td>0.546433</td>
      <td>0.453567</td>
      <td>0.551088</td>
      <td>0.448912</td>
      <td>0.546433</td>
      <td>0.004655</td>
      <td>-0.032244</td>
      <td>0.036899</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>2.0</td>
      <td>14:16</td>
      <td>15</td>
      <td>3556.0</td>
      <td>37.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>NaN</td>
      <td>0.551088</td>
      <td>0.448912</td>
      <td>0.510793</td>
      <td>0.489207</td>
      <td>0.551088</td>
      <td>-0.040295</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>3.0</td>
      <td>13:35</td>
      <td>14</td>
      <td>3515.0</td>
      <td>41.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>-5.031425</td>
      <td>0.510793</td>
      <td>0.489207</td>
      <td>0.461217</td>
      <td>0.538783</td>
      <td>0.510793</td>
      <td>-0.049576</td>
      <td>0.106663</td>
      <td>-0.156239</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>4.0</td>
      <td>13:27</td>
      <td>14</td>
      <td>3507.0</td>
      <td>8.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>NaN</td>
      <td>0.461217</td>
      <td>0.538783</td>
      <td>0.558929</td>
      <td>0.441071</td>
      <td>0.461217</td>
      <td>0.097712</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>362442</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>20</td>
      <td>4</td>
      <td>1.0</td>
      <td>00:22</td>
      <td>1</td>
      <td>22.0</td>
      <td>6.0</td>
      <td>GB</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.051901</td>
      <td>0.948099</td>
      <td>0.093435</td>
      <td>0.906565</td>
      <td>0.051901</td>
      <td>0.041534</td>
      <td>0.041534</td>
      <td>0.000000</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362443</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>20</td>
      <td>4</td>
      <td>NaN</td>
      <td>00:13</td>
      <td>1</td>
      <td>13.0</td>
      <td>9.0</td>
      <td>GB</td>
      <td>...</td>
      <td>NaN</td>
      <td>0.093435</td>
      <td>0.906565</td>
      <td>0.034069</td>
      <td>0.965931</td>
      <td>0.093435</td>
      <td>-0.059366</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362444</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>21</td>
      <td>4</td>
      <td>NaN</td>
      <td>00:13</td>
      <td>1</td>
      <td>13.0</td>
      <td>0.0</td>
      <td>DET</td>
      <td>...</td>
      <td>NaN</td>
      <td>0.034069</td>
      <td>0.965931</td>
      <td>0.035708</td>
      <td>0.964292</td>
      <td>0.965931</td>
      <td>-0.001639</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362445</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>21</td>
      <td>4</td>
      <td>1.0</td>
      <td>00:12</td>
      <td>1</td>
      <td>12.0</td>
      <td>1.0</td>
      <td>DET</td>
      <td>...</td>
      <td>NaN</td>
      <td>0.035708</td>
      <td>0.964292</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.964292</td>
      <td>0.035708</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362446</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>21</td>
      <td>4</td>
      <td>NaN</td>
      <td>00:00</td>
      <td>0</td>
      <td>0.0</td>
      <td>12.0</td>
      <td>DET</td>
      <td>...</td>
      <td>NaN</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.934245</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2016</td>
    </tr>
  </tbody>
</table>
<p>362447 rows × 102 columns</p>
</div>




```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GameID</th>
      <th>Drive</th>
      <th>qtr</th>
      <th>down</th>
      <th>TimeUnder</th>
      <th>TimeSecs</th>
      <th>PlayTimeDiff</th>
      <th>yrdln</th>
      <th>yrdline100</th>
      <th>ydstogo</th>
      <th>...</th>
      <th>yacEPA</th>
      <th>Home_WP_pre</th>
      <th>Away_WP_pre</th>
      <th>Home_WP_post</th>
      <th>Away_WP_post</th>
      <th>Win_Prob</th>
      <th>WPA</th>
      <th>airWPA</th>
      <th>yacWPA</th>
      <th>Season</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>3.624470e+05</td>
      <td>362447.000000</td>
      <td>362447.000000</td>
      <td>308229.000000</td>
      <td>362447.000000</td>
      <td>362259.000000</td>
      <td>362073.000000</td>
      <td>361724.000000</td>
      <td>361724.000000</td>
      <td>362447.000000</td>
      <td>...</td>
      <td>141713.000000</td>
      <td>340504.000000</td>
      <td>340504.000000</td>
      <td>339087.000000</td>
      <td>339087.000000</td>
      <td>340454.000000</td>
      <td>357630.000000</td>
      <td>141709.000000</td>
      <td>141491.000000</td>
      <td>362447.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.012664e+09</td>
      <td>12.347088</td>
      <td>2.578231</td>
      <td>2.001226</td>
      <td>7.386076</td>
      <td>1695.234346</td>
      <td>20.574649</td>
      <td>28.413542</td>
      <td>48.616807</td>
      <td>7.305236</td>
      <td>...</td>
      <td>-0.386522</td>
      <td>0.533889</td>
      <td>0.466561</td>
      <td>0.534217</td>
      <td>0.466185</td>
      <td>0.501311</td>
      <td>0.002163</td>
      <td>0.015209</td>
      <td>-0.010492</td>
      <td>2012.522071</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.292258e+06</td>
      <td>7.168173</td>
      <td>1.130259</td>
      <td>1.006003</td>
      <td>4.642132</td>
      <td>1063.065717</td>
      <td>18.030486</td>
      <td>13.002355</td>
      <td>25.161965</td>
      <td>4.863445</td>
      <td>...</td>
      <td>1.972964</td>
      <td>0.286415</td>
      <td>0.286468</td>
      <td>0.288647</td>
      <td>0.288694</td>
      <td>0.288207</td>
      <td>0.045326</td>
      <td>0.056422</td>
      <td>0.067972</td>
      <td>2.290084</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2.009091e+09</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>-900.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>...</td>
      <td>-14.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>-0.997214</td>
      <td>-0.999881</td>
      <td>-0.986673</td>
      <td>2009.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.011091e+09</td>
      <td>6.000000</td>
      <td>2.000000</td>
      <td>1.000000</td>
      <td>3.000000</td>
      <td>778.000000</td>
      <td>5.000000</td>
      <td>20.000000</td>
      <td>30.000000</td>
      <td>3.000000</td>
      <td>...</td>
      <td>-0.964562</td>
      <td>0.323129</td>
      <td>0.230595</td>
      <td>0.319464</td>
      <td>0.226867</td>
      <td>0.274964</td>
      <td>-0.014589</td>
      <td>-0.011355</td>
      <td>-0.018623</td>
      <td>2011.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.013091e+09</td>
      <td>12.000000</td>
      <td>3.000000</td>
      <td>2.000000</td>
      <td>7.000000</td>
      <td>1800.000000</td>
      <td>17.000000</td>
      <td>30.000000</td>
      <td>49.000000</td>
      <td>9.000000</td>
      <td>...</td>
      <td>0.000000</td>
      <td>0.531286</td>
      <td>0.469040</td>
      <td>0.533689</td>
      <td>0.466617</td>
      <td>0.504349</td>
      <td>0.000000</td>
      <td>0.003557</td>
      <td>0.000000</td>
      <td>2013.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.015091e+09</td>
      <td>18.000000</td>
      <td>4.000000</td>
      <td>3.000000</td>
      <td>11.000000</td>
      <td>2585.000000</td>
      <td>37.000000</td>
      <td>39.000000</td>
      <td>70.000000</td>
      <td>10.000000</td>
      <td>...</td>
      <td>0.484913</td>
      <td>0.770011</td>
      <td>0.677566</td>
      <td>0.773729</td>
      <td>0.681018</td>
      <td>0.726995</td>
      <td>0.014800</td>
      <td>0.035702</td>
      <td>0.011371</td>
      <td>2015.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.017010e+09</td>
      <td>35.000000</td>
      <td>5.000000</td>
      <td>4.000000</td>
      <td>15.000000</td>
      <td>3600.000000</td>
      <td>943.000000</td>
      <td>50.000000</td>
      <td>99.000000</td>
      <td>50.000000</td>
      <td>...</td>
      <td>9.559834</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.994848</td>
      <td>0.994848</td>
      <td>1.000000</td>
      <td>2016.000000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 64 columns</p>
</div>




```python
data.info()

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 362447 entries, 0 to 362446
    Columns: 102 entries, Date to Season
    dtypes: float64(33), int64(31), object(38)
    memory usage: 282.1+ MB
    


```python
data.shape
```




    (362447, 102)




```python
data.dtypes
```




    Date         object
    GameID        int64
    Drive         int64
    qtr           int64
    down        float64
                 ...   
    Win_Prob    float64
    WPA         float64
    airWPA      float64
    yacWPA      float64
    Season        int64
    Length: 102, dtype: object




```python
data.isnull().sum
```




    <bound method NDFrame._add_numeric_operations.<locals>.sum of          Date  GameID  Drive    qtr   down   time  TimeUnder  TimeSecs  \
    0       False   False  False  False   True  False      False     False   
    1       False   False  False  False  False  False      False     False   
    2       False   False  False  False  False  False      False     False   
    3       False   False  False  False  False  False      False     False   
    4       False   False  False  False  False  False      False     False   
    ...       ...     ...    ...    ...    ...    ...        ...       ...   
    362442  False   False  False  False  False  False      False     False   
    362443  False   False  False  False   True  False      False     False   
    362444  False   False  False  False   True  False      False     False   
    362445  False   False  False  False  False  False      False     False   
    362446  False   False  False  False   True  False      False     False   
    
            PlayTimeDiff  SideofField  ...  yacEPA  Home_WP_pre  Away_WP_pre  \
    0              False        False  ...    True        False        False   
    1              False        False  ...   False        False        False   
    2              False        False  ...    True        False        False   
    3              False        False  ...   False        False        False   
    4              False        False  ...    True        False        False   
    ...              ...          ...  ...     ...          ...          ...   
    362442         False        False  ...   False        False        False   
    362443         False        False  ...    True        False        False   
    362444         False        False  ...    True        False        False   
    362445         False        False  ...    True        False        False   
    362446         False        False  ...    True        False        False   
    
            Home_WP_post  Away_WP_post  Win_Prob    WPA  airWPA  yacWPA  Season  
    0              False         False     False  False    True    True   False  
    1              False         False     False  False   False   False   False  
    2              False         False     False  False    True    True   False  
    3              False         False     False  False   False   False   False  
    4              False         False     False  False    True    True   False  
    ...              ...           ...       ...    ...     ...     ...     ...  
    362442         False         False     False  False   False   False   False  
    362443         False         False     False  False    True    True   False  
    362444         False         False     False  False    True    True   False  
    362445         False         False     False  False    True    True   False  
    362446         False         False     False  False    True    True   False  
    
    [362447 rows x 102 columns]>




```python
data.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GameID</th>
      <th>Drive</th>
      <th>qtr</th>
      <th>down</th>
      <th>TimeUnder</th>
      <th>TimeSecs</th>
      <th>PlayTimeDiff</th>
      <th>yrdln</th>
      <th>yrdline100</th>
      <th>ydstogo</th>
      <th>...</th>
      <th>yacEPA</th>
      <th>Home_WP_pre</th>
      <th>Away_WP_pre</th>
      <th>Home_WP_post</th>
      <th>Away_WP_post</th>
      <th>Win_Prob</th>
      <th>WPA</th>
      <th>airWPA</th>
      <th>yacWPA</th>
      <th>Season</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>GameID</th>
      <td>1.000000</td>
      <td>-0.012673</td>
      <td>0.002154</td>
      <td>-0.006561</td>
      <td>-0.003915</td>
      <td>-0.003052</td>
      <td>-0.011033</td>
      <td>0.008703</td>
      <td>0.013137</td>
      <td>0.003289</td>
      <td>...</td>
      <td>0.011360</td>
      <td>0.016264</td>
      <td>-0.016448</td>
      <td>0.016104</td>
      <td>-0.016293</td>
      <td>-0.006905</td>
      <td>0.003030</td>
      <td>0.004493</td>
      <td>0.004227</td>
      <td>0.997106</td>
    </tr>
    <tr>
      <th>Drive</th>
      <td>-0.012673</td>
      <td>1.000000</td>
      <td>0.916856</td>
      <td>-0.007109</td>
      <td>-0.248533</td>
      <td>-0.942498</td>
      <td>-0.090929</td>
      <td>0.010163</td>
      <td>-0.031506</td>
      <td>-0.022388</td>
      <td>...</td>
      <td>-0.029907</td>
      <td>0.035059</td>
      <td>-0.032119</td>
      <td>0.034472</td>
      <td>-0.031883</td>
      <td>-0.039204</td>
      <td>-0.015634</td>
      <td>0.040558</td>
      <td>-0.042858</td>
      <td>-0.012653</td>
    </tr>
    <tr>
      <th>qtr</th>
      <td>0.002154</td>
      <td>0.916856</td>
      <td>1.000000</td>
      <td>0.009480</td>
      <td>-0.031486</td>
      <td>-0.964963</td>
      <td>-0.056918</td>
      <td>0.001969</td>
      <td>-0.048516</td>
      <td>-0.013326</td>
      <td>...</td>
      <td>-0.028191</td>
      <td>0.035110</td>
      <td>-0.031733</td>
      <td>0.034634</td>
      <td>-0.031626</td>
      <td>-0.030980</td>
      <td>-0.008323</td>
      <td>0.044653</td>
      <td>-0.042261</td>
      <td>0.002455</td>
    </tr>
    <tr>
      <th>down</th>
      <td>-0.006561</td>
      <td>-0.007109</td>
      <td>0.009480</td>
      <td>1.000000</td>
      <td>-0.020911</td>
      <td>-0.014882</td>
      <td>0.019948</td>
      <td>0.003937</td>
      <td>-0.050023</td>
      <td>-0.247069</td>
      <td>...</td>
      <td>-0.106719</td>
      <td>0.000143</td>
      <td>-0.000143</td>
      <td>0.000417</td>
      <td>-0.000417</td>
      <td>-0.032092</td>
      <td>0.068759</td>
      <td>0.099642</td>
      <td>-0.079001</td>
      <td>-0.006658</td>
    </tr>
    <tr>
      <th>TimeUnder</th>
      <td>-0.003915</td>
      <td>-0.248533</td>
      <td>-0.031486</td>
      <td>-0.020911</td>
      <td>1.000000</td>
      <td>0.291991</td>
      <td>0.099406</td>
      <td>0.014597</td>
      <td>0.131375</td>
      <td>0.088855</td>
      <td>...</td>
      <td>0.018210</td>
      <td>-0.012961</td>
      <td>0.012779</td>
      <td>-0.012516</td>
      <td>0.012534</td>
      <td>0.020691</td>
      <td>0.025297</td>
      <td>-0.034880</td>
      <td>0.036520</td>
      <td>-0.003878</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>Win_Prob</th>
      <td>-0.006905</td>
      <td>-0.039204</td>
      <td>-0.030980</td>
      <td>-0.032092</td>
      <td>0.020691</td>
      <td>0.035047</td>
      <td>0.099594</td>
      <td>-0.024873</td>
      <td>-0.165621</td>
      <td>-0.025925</td>
      <td>...</td>
      <td>0.029928</td>
      <td>0.001128</td>
      <td>-0.003857</td>
      <td>0.002031</td>
      <td>-0.004460</td>
      <td>1.000000</td>
      <td>-0.028168</td>
      <td>-0.039660</td>
      <td>0.025705</td>
      <td>-0.007124</td>
    </tr>
    <tr>
      <th>WPA</th>
      <td>0.003030</td>
      <td>-0.015634</td>
      <td>-0.008323</td>
      <td>0.068759</td>
      <td>0.025297</td>
      <td>0.014653</td>
      <td>-0.007772</td>
      <td>-0.029280</td>
      <td>0.020932</td>
      <td>-0.004606</td>
      <td>...</td>
      <td>0.566408</td>
      <td>-0.001981</td>
      <td>0.003723</td>
      <td>-0.000938</td>
      <td>0.000418</td>
      <td>-0.028168</td>
      <td>1.000000</td>
      <td>0.194425</td>
      <td>0.604530</td>
      <td>0.003242</td>
    </tr>
    <tr>
      <th>airWPA</th>
      <td>0.004493</td>
      <td>0.040558</td>
      <td>0.044653</td>
      <td>0.099642</td>
      <td>-0.034880</td>
      <td>-0.051969</td>
      <td>-0.016244</td>
      <td>-0.094221</td>
      <td>-0.064046</td>
      <td>-0.073285</td>
      <td>...</td>
      <td>-0.405641</td>
      <td>-0.013959</td>
      <td>0.013959</td>
      <td>-0.011161</td>
      <td>0.011161</td>
      <td>-0.039660</td>
      <td>0.194425</td>
      <td>1.000000</td>
      <td>-0.663846</td>
      <td>0.004691</td>
    </tr>
    <tr>
      <th>yacWPA</th>
      <td>0.004227</td>
      <td>-0.042858</td>
      <td>-0.042261</td>
      <td>-0.079001</td>
      <td>0.036520</td>
      <td>0.050232</td>
      <td>0.010402</td>
      <td>0.042066</td>
      <td>0.066607</td>
      <td>0.042080</td>
      <td>...</td>
      <td>0.766654</td>
      <td>0.007399</td>
      <td>-0.007399</td>
      <td>0.006557</td>
      <td>-0.006557</td>
      <td>0.025705</td>
      <td>0.604530</td>
      <td>-0.663846</td>
      <td>1.000000</td>
      <td>0.004290</td>
    </tr>
    <tr>
      <th>Season</th>
      <td>0.997106</td>
      <td>-0.012653</td>
      <td>0.002455</td>
      <td>-0.006658</td>
      <td>-0.003878</td>
      <td>-0.003333</td>
      <td>-0.011198</td>
      <td>0.008394</td>
      <td>0.013320</td>
      <td>0.003603</td>
      <td>...</td>
      <td>0.011597</td>
      <td>0.016250</td>
      <td>-0.016421</td>
      <td>0.016099</td>
      <td>-0.016278</td>
      <td>-0.007124</td>
      <td>0.003242</td>
      <td>0.004691</td>
      <td>0.004290</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>64 rows × 64 columns</p>
</div>




```python
##Data Analyst  Data Cleaning & Processing Checking for missing values

```


```python
overall_missing_percentage = (data.isnull().sum().sum() / (len(data) * len(data.columns))) * 100
print(f"Overall Missing Percentage: {overall_missing_percentage:.2f}%")

```

    Overall Missing Percentage: 24.86%
    


```python
# We have 24.86% missing values in the data
```


```python
#Checking the missing values %
100*data.isnull().mean().sort_values(ascending = False)
```




    DefTwoPoint         99.996137
    BlockingPlayer      99.970754
    TwoPointConv        99.854324
    ChalReplayResult    99.180294
    RecFumbTeam         98.914600
                          ...    
    Fumble               0.000000
    Sack                 0.000000
    Challenge.Replay     0.000000
    Accepted.Penalty     0.000000
    Season               0.000000
    Length: 102, dtype: float64




```python
#After analysing columns by % of missing values i assumed, the removing them won't affect my further calculation 

```


```python
#findind the columns with more than 40% missing values and assigning them into a new list 
cutoff=40
cols_to_drop=list(data.columns[100*data.isnull().mean()>cutoff])
#print the list of columns to be dropped
cols_to_drop
```




    ['ExPointResult',
     'TwoPointConv',
     'DefTwoPoint',
     'PuntResult',
     'Passer',
     'PassOutcome',
     'PassLength',
     'PassLocation',
     'Interceptor',
     'Rusher',
     'RunLocation',
     'RunGap',
     'Receiver',
     'ReturnResult',
     'Returner',
     'BlockingPlayer',
     'Tackler1',
     'Tackler2',
     'FieldGoalResult',
     'FieldGoalDistance',
     'RecFumbTeam',
     'RecFumbPlayer',
     'ChalReplayResult',
     'PenalizedTeam',
     'PenaltyType',
     'PenalizedPlayer',
     'airEPA',
     'yacEPA',
     'airWPA',
     'yacWPA']




```python
#Dropping the columns with more than 40% missing data

```


```python
#dropping the columns
data=data.drop(cols_to_drop,axis=1)
```


```python
#checking the shape of the data after dropping the columns
data.shape
```




    (362447, 72)




```python
#Now totol columns reduced to 120 to 72

```


```python
#checking again for missing values percentage
check_null=(data.isna().sum()/len(data)*100).sort_values(ascending = False)
check_null
```




    down                14.958877
    FirstDown            7.062274
    DefTeamScore         6.533921
    AbsScoreDiff         6.533921
    PosTeamScore         6.533921
                          ...    
    Reception            0.000000
    GameID               0.000000
    Sack                 0.000000
    Challenge.Replay     0.000000
    Season               0.000000
    Length: 72, dtype: float64




```python
#Further cleaning dataset
#Dropping the Duplicates
```


```python
#checking for duplicates
data=data.drop_duplicates()
```


```python
duplicates = data[data.duplicated()]
num_duplicates = duplicates.shape[0]
print("Number of Duplicate Rows", num_duplicates)
```

    Number of Duplicate Rows 0
    


```python
#checking overall missing percentage again
overall_missing_percentage = (data.isnull().sum().sum() / (len(data) * len(data.columns))) *100
print(f"Overall Missing Percentage: {overall_missing_percentage:.2f}%")
```

    Overall Missing Percentage: 1.30%
    


```python
#Diving the rest of tyhe columns in two catagories
#1. Cat_col: Cateforical Columns
#2. Num_col : Numerical Columns

Cat_col = sorted(data.columns[data.nunique()<60])
Cat_col
```




    ['AbsScoreDiff',
     'Accepted.Penalty',
     'AwayTeam',
     'AwayTimeouts_Remaining_Post',
     'AwayTimeouts_Remaining_Pre',
     'Challenge.Replay',
     'DefensiveTeam',
     'Drive',
     'ExPoint_Prob',
     'FirstDown',
     'Fumble',
     'GoalToGo',
     'HomeTeam',
     'HomeTimeouts_Remaining_Post',
     'HomeTimeouts_Remaining_Pre',
     'InterceptionThrown',
     'Onsidekick',
     'PassAttempt',
     'Penalty.Yards',
     'PlayAttempted',
     'PlayType',
     'QBHit',
     'Reception',
     'RushAttempt',
     'Sack',
     'Safety',
     'Season',
     'SideofField',
     'TimeUnder',
     'Timeout_Indicator',
     'Timeout_Team',
     'Touchdown',
     'TwoPoint_Prob',
     'down',
     'posteam',
     'posteam_timeouts_pre',
     'qtr',
     'sp',
     'ydstogo',
     'yrdln']




```python
Num_col=sorted(data.columns[data.nunique()>60])
Num_col
```




    ['AirYards',
     'Away_WP_post',
     'Away_WP_pre',
     'Date',
     'EPA',
     'ExpPts',
     'Field_Goal_Prob',
     'GameID',
     'Home_WP_post',
     'Home_WP_pre',
     'No_Score_Prob',
     'Opp_Field_Goal_Prob',
     'Opp_Safety_Prob',
     'Opp_Touchdown_Prob',
     'Passer_ID',
     'PlayTimeDiff',
     'PosTeamScore',
     'Receiver_ID',
     'Rusher_ID',
     'Safety_Prob',
     'ScoreDiff',
     'TimeSecs',
     'Touchdown_Prob',
     'WPA',
     'Win_Prob',
     'Yards.Gained',
     'YardsAfterCatch',
     'desc',
     'time',
     'ydsnet',
     'yrdline100']




```python
#Defining a function to impute missing values in categorical columns
#import the Cat_col with mode
def impute_missing_values(data, cat_columns):
    for col in cat_columns:
        mode_value = data[col].mode()[0]
        data[col].fillna(mode_value, inplace=True)
    return data

```


```python
data1 = impute_missing_values(data,Cat_col)
data1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>GameID</th>
      <th>Drive</th>
      <th>qtr</th>
      <th>down</th>
      <th>time</th>
      <th>TimeUnder</th>
      <th>TimeSecs</th>
      <th>PlayTimeDiff</th>
      <th>SideofField</th>
      <th>...</th>
      <th>TwoPoint_Prob</th>
      <th>ExpPts</th>
      <th>EPA</th>
      <th>Home_WP_pre</th>
      <th>Away_WP_pre</th>
      <th>Home_WP_post</th>
      <th>Away_WP_post</th>
      <th>Win_Prob</th>
      <th>WPA</th>
      <th>Season</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>1.0</td>
      <td>15:00</td>
      <td>15</td>
      <td>3600.0</td>
      <td>0.0</td>
      <td>TEN</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.323526</td>
      <td>2.014474</td>
      <td>0.485675</td>
      <td>0.514325</td>
      <td>0.546433</td>
      <td>0.453567</td>
      <td>0.485675</td>
      <td>0.060758</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>1.0</td>
      <td>14:53</td>
      <td>15</td>
      <td>3593.0</td>
      <td>7.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>0.0</td>
      <td>2.338000</td>
      <td>0.077907</td>
      <td>0.546433</td>
      <td>0.453567</td>
      <td>0.551088</td>
      <td>0.448912</td>
      <td>0.546433</td>
      <td>0.004655</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>2.0</td>
      <td>14:16</td>
      <td>15</td>
      <td>3556.0</td>
      <td>37.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>0.0</td>
      <td>2.415907</td>
      <td>-1.402760</td>
      <td>0.551088</td>
      <td>0.448912</td>
      <td>0.510793</td>
      <td>0.489207</td>
      <td>0.551088</td>
      <td>-0.040295</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>3.0</td>
      <td>13:35</td>
      <td>14</td>
      <td>3515.0</td>
      <td>41.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>0.0</td>
      <td>1.013147</td>
      <td>-1.712583</td>
      <td>0.510793</td>
      <td>0.489207</td>
      <td>0.461217</td>
      <td>0.538783</td>
      <td>0.510793</td>
      <td>-0.049576</td>
      <td>2009</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2009-09-10</td>
      <td>2009091000</td>
      <td>1</td>
      <td>1</td>
      <td>4.0</td>
      <td>13:27</td>
      <td>14</td>
      <td>3507.0</td>
      <td>8.0</td>
      <td>PIT</td>
      <td>...</td>
      <td>0.0</td>
      <td>-0.699436</td>
      <td>2.097796</td>
      <td>0.461217</td>
      <td>0.538783</td>
      <td>0.558929</td>
      <td>0.441071</td>
      <td>0.461217</td>
      <td>0.097712</td>
      <td>2009</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 72 columns</p>
</div>




```python
#We have not imputed the numerical columns because it can differ the outcomes
#checking overall missing percentage again
overall_missing_percentage = (data1.isnull().sum().sum() / (len(data1) * len(data1.columns))) *100
print(f"Overall Missing Percentage: {overall_missing_percentage:.2f}%")

```

    Overall Missing Percentage: 0.73%
    


```python
#the missing percentages is 0.73% which can be considered negligible

```


```python
#Handling Outliers
len(Num_col)
```




    31




```python
import matplotlib.pyplot as plt
import seaborn as sns

plt.style.use('ggplot')
plt.figure(figsize=(20, 10))

for i, col in enumerate(Num_col, 1):
    plt.subplot(5, 5, i)
    sns.boxplot(data1[col].dropna())
    plt.title(f'Distribution of {col}')

plt.tight_layout()
plt.show()

```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    ~\AppData\Local\Temp\ipykernel_6276\895433624.py in <module>
          7 for i, col in enumerate(Num_col, 1):
          8     plt.subplot(5, 5, i)
    ----> 9     sns.boxplot(data1[col].dropna())
         10     plt.title(f'Distribution of {col}')
         11 
    

    ~\anaconda3\lib\site-packages\seaborn\_decorators.py in inner_f(*args, **kwargs)
         44             )
         45         kwargs.update({k: arg for k, arg in zip(sig.parameters, args)})
    ---> 46         return f(**kwargs)
         47     return inner_f
         48 
    

    ~\anaconda3\lib\site-packages\seaborn\categorical.py in boxplot(x, y, hue, data, order, hue_order, orient, color, palette, saturation, width, dodge, fliersize, linewidth, whis, ax, **kwargs)
       2241 ):
       2242 
    -> 2243     plotter = _BoxPlotter(x, y, hue, data, order, hue_order,
       2244                           orient, color, palette, saturation,
       2245                           width, dodge, fliersize, linewidth)
    

    ~\anaconda3\lib\site-packages\seaborn\categorical.py in __init__(self, x, y, hue, data, order, hue_order, orient, color, palette, saturation, width, dodge, fliersize, linewidth)
        404                  width, dodge, fliersize, linewidth):
        405 
    --> 406         self.establish_variables(x, y, hue, data, orient, order, hue_order)
        407         self.establish_colors(color, palette, saturation)
        408 
    

    ~\anaconda3\lib\site-packages\seaborn\categorical.py in establish_variables(self, x, y, hue, data, orient, order, hue_order, units)
        154 
        155             # Figure out the plotting orientation
    --> 156             orient = infer_orient(
        157                 x, y, orient, require_numeric=self.require_numeric
        158             )
    

    ~\anaconda3\lib\site-packages\seaborn\_core.py in infer_orient(x, y, orient, require_numeric)
       1326             warnings.warn(single_var_warning.format("Vertical", "x"))
       1327         if require_numeric and x_type != "numeric":
    -> 1328             raise TypeError(nonnumeric_dv_error.format("Horizontal", "x"))
       1329         return "h"
       1330 
    

    TypeError: Horizontal orientation requires numeric `x` variable.



    
![png](output_30_1.png)
    



```python
#further analysis for EDA
#Checking the values counts of GameID
game_id_value_counts = data1['GameID'].value_counts()
print(game_id_value_counts)
```

    2011120406    272
    2016112709    232
    2016103000    231
    2012112200    229
    2013112403    229
                 ... 
    2015092705    146
    2012110100    146
    2009122706    145
    2013090801    145
    2013120806    125
    Name: GameID, Length: 2048, dtype: int64
    


```python
data1.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Date</th>
      <th>GameID</th>
      <th>Drive</th>
      <th>qtr</th>
      <th>down</th>
      <th>time</th>
      <th>TimeUnder</th>
      <th>TimeSecs</th>
      <th>PlayTimeDiff</th>
      <th>SideofField</th>
      <th>...</th>
      <th>TwoPoint_Prob</th>
      <th>ExpPts</th>
      <th>EPA</th>
      <th>Home_WP_pre</th>
      <th>Away_WP_pre</th>
      <th>Home_WP_post</th>
      <th>Away_WP_post</th>
      <th>Win_Prob</th>
      <th>WPA</th>
      <th>Season</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>362442</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>20</td>
      <td>4</td>
      <td>1.0</td>
      <td>00:22</td>
      <td>1</td>
      <td>22.0</td>
      <td>6.0</td>
      <td>GB</td>
      <td>...</td>
      <td>0.0</td>
      <td>2.379997</td>
      <td>4.620003</td>
      <td>0.051901</td>
      <td>0.948099</td>
      <td>0.093435</td>
      <td>0.906565</td>
      <td>0.051901</td>
      <td>0.041534</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362443</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>20</td>
      <td>4</td>
      <td>1.0</td>
      <td>00:13</td>
      <td>1</td>
      <td>13.0</td>
      <td>9.0</td>
      <td>GB</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.931115</td>
      <td>0.068885</td>
      <td>0.093435</td>
      <td>0.906565</td>
      <td>0.034069</td>
      <td>0.965931</td>
      <td>0.093435</td>
      <td>-0.059366</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362444</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>21</td>
      <td>4</td>
      <td>1.0</td>
      <td>00:13</td>
      <td>1</td>
      <td>13.0</td>
      <td>0.0</td>
      <td>DET</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.692792</td>
      <td>-0.692792</td>
      <td>0.034069</td>
      <td>0.965931</td>
      <td>0.035708</td>
      <td>0.964292</td>
      <td>0.965931</td>
      <td>-0.001639</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362445</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>21</td>
      <td>4</td>
      <td>1.0</td>
      <td>00:12</td>
      <td>1</td>
      <td>12.0</td>
      <td>1.0</td>
      <td>DET</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.035708</td>
      <td>0.964292</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.964292</td>
      <td>0.035708</td>
      <td>2016</td>
    </tr>
    <tr>
      <th>362446</th>
      <td>2017-01-01</td>
      <td>2017010102</td>
      <td>21</td>
      <td>4</td>
      <td>1.0</td>
      <td>00:00</td>
      <td>0</td>
      <td>0.0</td>
      <td>12.0</td>
      <td>DET</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
      <td>0.934245</td>
      <td>0.000000</td>
      <td>2016</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 72 columns</p>
</div>




```python
#checking the END GAME gameID 
#sekecting one gameID with final score for filtering rows
filtered_rows = data1[data1['GameID'] == 201710102]
print(filtered_rows[['HomeTeam','AwayTeam','Home_WP_post','Away_WP_post','PosTeamScore','DefTeamScore']])

```

    Empty DataFrame
    Columns: [HomeTeam, AwayTeam, Home_WP_post, Away_WP_post, PosTeamScore, DefTeamScore]
    Index: []
    


```python
#getting end of the extra rows, so we can have rows only with final score in each game
columns_to_keep = ['GameID','Date','HomeTeam','AwayTeam','Home_WP_post','Away_WP_post','PosTeamScore','DefTeamScore',
                  'WPA','ScoreDiff','Season','Win_Prob']
final_scores = data1.groupby('GameID')[columns_to_keep].tail(1)
print(final_scores)
```

                GameID        Date HomeTeam AwayTeam  Home_WP_post  Away_WP_post  \
    177     2009091000  2009-09-10      PIT      TEN           NaN           NaN   
    349     2009091304  2009-09-13      CLE      MIN           0.0           1.0   
    531     2009091307  2009-09-13       NO      DET           1.0           0.0   
    702     2009091308  2009-09-13       TB      DAL           0.0           1.0   
    865     2009091305  2009-09-13      HOU      NYJ           0.0           1.0   
    ...            ...         ...      ...      ...           ...           ...   
    361723  2017010112  2017-01-01      DEN      OAK           1.0           0.0   
    361889  2017010111  2017-01-01      WAS      NYG           NaN           NaN   
    362062  2017010115  2017-01-01       SF      SEA           0.0           1.0   
    362256  2017010100  2017-01-01      ATL       NO           1.0           0.0   
    362446  2017010102  2017-01-01      DET       GB           0.0           1.0   
    
            PosTeamScore  DefTeamScore  WPA  ScoreDiff  Season      Win_Prob  
    177             10.0          10.0  NaN        0.0    2009  9.555270e-01  
    349              NaN           NaN  0.0       15.0    2009  4.373296e-11  
    531              NaN           NaN  0.0       19.0    2009  2.220446e-16  
    702              NaN           NaN  0.0       13.0    2009  3.281873e-08  
    865              NaN           NaN  0.0       18.0    2009  2.220446e-16  
    ...              ...           ...  ...        ...     ...           ...  
    361723           NaN           NaN  0.0       18.0    2016  2.220446e-16  
    361889          10.0          13.0  NaN       -3.0    2016  8.348558e-02  
    362062           NaN           NaN  0.0        2.0    2016  9.941040e-01  
    362256           NaN           NaN  0.0        6.0    2016  9.949601e-01  
    362446           NaN           NaN  0.0        7.0    2016  9.342446e-01  
    
    [2048 rows x 12 columns]
    


```python
final_scores.sample(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GameID</th>
      <th>Date</th>
      <th>HomeTeam</th>
      <th>AwayTeam</th>
      <th>Home_WP_post</th>
      <th>Away_WP_post</th>
      <th>PosTeamScore</th>
      <th>DefTeamScore</th>
      <th>WPA</th>
      <th>ScoreDiff</th>
      <th>Season</th>
      <th>Win_Prob</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>281113</th>
      <td>2015100408</td>
      <td>2015-10-04</td>
      <td>SD</td>
      <td>CLE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>27.0</td>
      <td>27.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2015</td>
      <td>9.991065e-01</td>
    </tr>
    <tr>
      <th>309034</th>
      <td>2015122007</td>
      <td>2015-12-20</td>
      <td>WAS</td>
      <td>BUF</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>10.0</td>
      <td>2015</td>
      <td>8.759278e-04</td>
    </tr>
    <tr>
      <th>27714</th>
      <td>2009112213</td>
      <td>2009-11-22</td>
      <td>CHI</td>
      <td>PHI</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>2009</td>
      <td>9.996989e-01</td>
    </tr>
    <tr>
      <th>99758</th>
      <td>2011100209</td>
      <td>2011-10-02</td>
      <td>ARI</td>
      <td>NYG</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>4.0</td>
      <td>2011</td>
      <td>9.996294e-01</td>
    </tr>
    <tr>
      <th>350974</th>
      <td>2016120412</td>
      <td>2016-12-04</td>
      <td>SEA</td>
      <td>CAR</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>-33.0</td>
      <td>2016</td>
      <td>2.220446e-16</td>
    </tr>
    <tr>
      <th>357289</th>
      <td>2016122406</td>
      <td>2016-12-24</td>
      <td>NE</td>
      <td>NYJ</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>38.0</td>
      <td>2016</td>
      <td>2.220446e-16</td>
    </tr>
    <tr>
      <th>75695</th>
      <td>2010120200</td>
      <td>2010-12-02</td>
      <td>PHI</td>
      <td>HOU</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>-10.0</td>
      <td>2010</td>
      <td>3.510945e-06</td>
    </tr>
    <tr>
      <th>231863</th>
      <td>2014092106</td>
      <td>2014-09-21</td>
      <td>NO</td>
      <td>MIN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>11.0</td>
      <td>2014</td>
      <td>3.401960e-05</td>
    </tr>
    <tr>
      <th>7820</th>
      <td>2009092713</td>
      <td>2009-09-27</td>
      <td>SD</td>
      <td>MIA</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>-9.0</td>
      <td>2009</td>
      <td>1.694931e-05</td>
    </tr>
    <tr>
      <th>85379</th>
      <td>2010122607</td>
      <td>2010-12-26</td>
      <td>MIA</td>
      <td>DET</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>-6.0</td>
      <td>2010</td>
      <td>1.412793e-03</td>
    </tr>
    <tr>
      <th>297292</th>
      <td>2015111900</td>
      <td>2015-11-19</td>
      <td>JAC</td>
      <td>TEN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>-6.0</td>
      <td>2015</td>
      <td>1.268556e-03</td>
    </tr>
    <tr>
      <th>311613</th>
      <td>2015122705</td>
      <td>2015-12-27</td>
      <td>DET</td>
      <td>SF</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>15.0</td>
      <td>2015</td>
      <td>5.425905e-11</td>
    </tr>
    <tr>
      <th>120828</th>
      <td>2011120413</td>
      <td>2011-12-04</td>
      <td>NE</td>
      <td>IND</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>2011</td>
      <td>9.509961e-01</td>
    </tr>
    <tr>
      <th>265292</th>
      <td>2014122000</td>
      <td>2014-12-20</td>
      <td>WAS</td>
      <td>PHI</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>-3.0</td>
      <td>2014</td>
      <td>1.137303e-01</td>
    </tr>
    <tr>
      <th>290191</th>
      <td>2015110105</td>
      <td>2015-11-01</td>
      <td>ATL</td>
      <td>TB</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>23.0</td>
      <td>NaN</td>
      <td>-3.0</td>
      <td>2015</td>
      <td>2.602312e-01</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Creating points by scores in the game
#Creating function to calculate points by scores in the game
def calculate_points(row):
    if row['Home_WP_post'] > row['Away_WP_post']:
        return 2,0
    elif row['Home_WP_post'] < row['Away_WP_post']:
        return 0,2
    else:
        if row['PosTeamScore'] > row['DefTeamScore']:
            return 2,1
        elif row['PosTeamScore'] < row['DefTeamScore']:
            return 0,2
        else:
            return 1,1
final_scores['home_team_points'], final_scores['away_team_points'] = zip(*final_score.apply(calculate_points,axis=1))
```


```python
filtered_games= final_scores[(final_scores['home_team_points'] == 1) | (final_scores['away_team_points'] == 1)]
filtered_games.head(15)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>GameID</th>
      <th>Date</th>
      <th>HomeTeam</th>
      <th>AwayTeam</th>
      <th>Home_WP_post</th>
      <th>Away_WP_post</th>
      <th>PosTeamScore</th>
      <th>DefTeamScore</th>
      <th>WPA</th>
      <th>ScoreDiff</th>
      <th>Season</th>
      <th>Win_Prob</th>
      <th>home_team_points</th>
      <th>away_team_points</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>177</th>
      <td>2009091000</td>
      <td>2009-09-10</td>
      <td>PIT</td>
      <td>TEN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>10.0</td>
      <td>10.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.955527</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4724</th>
      <td>2009092009</td>
      <td>2009-09-20</td>
      <td>BUF</td>
      <td>TB</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>2009</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>7305</th>
      <td>2009092709</td>
      <td>2009-09-27</td>
      <td>BUF</td>
      <td>NO</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>2009</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>11313</th>
      <td>2009101104</td>
      <td>2009-10-11</td>
      <td>KC</td>
      <td>DAL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>20.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.561189</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>12674</th>
      <td>2009101110</td>
      <td>2009-10-11</td>
      <td>DEN</td>
      <td>NE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>17.0</td>
      <td>17.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.881082</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>13720</th>
      <td>2009101802</td>
      <td>2009-10-18</td>
      <td>JAC</td>
      <td>STL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>20.0</td>
      <td>19.0</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>2009</td>
      <td>0.924474</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>15307</th>
      <td>2009101811</td>
      <td>2009-10-18</td>
      <td>NYJ</td>
      <td>BUF</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>13.0</td>
      <td>13.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.780864</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>17888</th>
      <td>2009102600</td>
      <td>2009-10-26</td>
      <td>WAS</td>
      <td>PHI</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>26.0</td>
      <td>17.0</td>
      <td>NaN</td>
      <td>9.0</td>
      <td>2009</td>
      <td>0.991181</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>18223</th>
      <td>2009110101</td>
      <td>2009-11-01</td>
      <td>BUF</td>
      <td>HOU</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>2009</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22768</th>
      <td>2009111500</td>
      <td>2009-11-15</td>
      <td>CAR</td>
      <td>ATL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>28.0</td>
      <td>19.0</td>
      <td>NaN</td>
      <td>9.0</td>
      <td>2009</td>
      <td>0.999881</td>
      <td>2</td>
      <td>1</td>
    </tr>
    <tr>
      <th>25799</th>
      <td>2009112207</td>
      <td>2009-11-22</td>
      <td>NYG</td>
      <td>ATL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>31.0</td>
      <td>31.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.929026</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>26145</th>
      <td>2009112205</td>
      <td>2009-11-22</td>
      <td>KC</td>
      <td>PIT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>24.0</td>
      <td>24.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.990219</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>26665</th>
      <td>2009112202</td>
      <td>2009-11-22</td>
      <td>DET</td>
      <td>CLE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.0</td>
      <td>37.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2009</td>
      <td>0.803443</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>28579</th>
      <td>2009112901</td>
      <td>2009-11-29</td>
      <td>BUF</td>
      <td>MIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>2009</td>
      <td>NaN</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>30136</th>
      <td>2009112908</td>
      <td>2009-11-29</td>
      <td>TEN</td>
      <td>ARI</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>19.0</td>
      <td>17.0</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>2009</td>
      <td>0.999235</td>
      <td>2</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
#which team is best
team_points = {}
for index, row in final_scores.iterrows():
    home_team = row['HomeTeam']
    if home_team in team_points:
        team_points[home_team] == row['home_team_points']
    else:
        team_points[home_team] = row['home_team_points']
        
    
    away_team = row['AwayTeam']
    if away_team in team_points:
        team_points[away_team] == row['away_team_points']
    else:
        team_points[away_team] = row['away_team_points']
total_points_data = pd.DataFrame(list(team_points.items()),columns=['Team','Total_Points'])
total_points_data = total_points_data.sort_values(by='Total_Points',ascending=False)
print(total_points_data)
```

       Team  Total_Points
    28   NE             2
    10  IND             2
    21   SF             2
    25  WAS             2
    18  ATL             2
    16  BAL             2
    15  PHI             2
    26   GB             2
    13  DEN             2
    22  SEA             2
    9   NYJ             2
    7   DAL             2
    31   SD             2
    4    NO             2
    3   MIN             2
    1   TEN             1
    0   PIT             1
    23  STL             0
    27  CHI             0
    29  BUF             0
    30  OAK             0
    24  NYG             0
    32   LA             0
    17   KC             0
    20  ARI             0
    19  MIA             0
    14  CAR             0
    12  CIN             0
    11  JAC             0
    8   HOU             0
    6    TB             0
    5   DET             0
    2   CLE             0
    33  JAX             0
    


```python
import warnings
import matplotlib.pyplot as plt
import numpy as np

warnings.filterwarnings('ignore')

total_points_data = total_points_data.sort_values(by='Total_Points', ascending=False)

plt.figure(figsize=(12, 8))
bars = plt.bar(total_points_data['Team'], total_points_data['Total_Points'], color=plt.cm.viridis(norm(total_points_data['Total_Points'])))

# Setting up colorbar
sm = plt.cm.ScalarMappable(cmap='viridis', norm=norm)
sm.set_array([])
cbar = plt.colorbar(sm)
cbar.set_label('Total Points')

plt.xlabel('Team')
plt.ylabel('Total Points')
plt.title('Total Points Scored by Team 2009-2016')

plt.xticks(rotation=90)
plt.tight_layout()
plt.show()

```


    
![png](output_39_0.png)
    



```python
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

plt.style.use('seaborn')

all_points_data = []

for index, row in final_scores.iterrows():
    all_points_data.extend([(row['Date'][:4], row['HomeTeam'], row['home_team_points']),
                            (row['Date'][:4], row['AwayTeam'], row['away_team_points'])])

data = pd.DataFrame(all_points_data, columns=['Year', 'Team', 'Points'])
data = data.groupby(['Year', 'Team'])['Points'].sum().reset_index()

# get unique years except 2016
years = data['Year'].unique()
num_years = len(years)

# create subplots
fig, axes = plt.subplots(nrows=num_years, ncols=1, figsize=(12, 6*num_years))

# plot each year in a subplot
for i, year in enumerate(years):
    data_year = data[data['Year'] == year]
    ax = axes[i] if num_years > 1 else axes
    sns.barplot(data=data_year, x='Team', y="Points", ax=ax)
    ax.set_title(f'Total Points by Team For Year {year}')
    ax.set_xlabel('Team')
    ax.set_ylabel('Total Points')
    ax.grid(True)
    ax.set_xticklabels(ax.get_xticklabels(), rotation=45)
    for p in ax.patches:
        ax.annotate(f"{p.get_height()}", (p.get_x() + p.get_width() / 2., p.get_height()),
                    ha='center', va='center', fontsize=10, color='black', xytext=(0, 5),
                    textcoords='offset points')
plt.tight_layout()
plt.show()

```


    
![png](output_40_0.png)
    



```python
import matplotlib.pyplot as plt
import pandas as pd

home_wins = final_scores[final_scores['home_team_points'] > final_scores['away_team_points']].shape[0]
away_wins = final_scores[final_scores['away_team_points'] > final_scores['home_team_points']].shape[0]

total_games = final_scores.shape[0]

home_win_percentage = (home_wins / total_games) * 100
away_win_percentage = (away_wins / total_games) * 100

win_data = pd.DataFrame({
    'Location': ['Home', 'Away'],
    'Win Percentage': [home_win_percentage, away_win_percentage]
})

plt.figure(figsize=(8, 6))
plt.bar(win_data['Location'], win_data['Win Percentage'], color=['skyblue', 'salmon'])
plt.xlabel('Location')
plt.ylabel('Win Percentage')
plt.title('Win Percentage Comparison: Home vs Away')
plt.ylim(0, 100)
plt.show()



```


    
![png](output_41_0.png)
    



```python

```
